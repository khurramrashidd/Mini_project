import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Sun, Moon, LogOut, Menu, X, Shield, History, Settings, KeySquare } from 'lucide-react';
import { auth } from '../firebase';
import { signOut } from 'firebase/auth';
import '../styles/layout.css';

export default function Layout({ isDark, setIsDark, user, userData, children }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const location = useLocation();

  const toggleTheme = () => {
    setIsDark(!isDark);
    if (!isDark) document.documentElement.classList.add('dark');
    else document.documentElement.classList.remove('dark');
  };

  const handleLogout = () => {
    signOut(auth);
  };

  return (
    <div className="app-layout">
      {sidebarOpen && <div className="sidebar-overlay" onClick={() => setSidebarOpen(false)}></div>}

      <aside className={`sidebar ${sidebarOpen ? 'open' : ''}`}>
        <div className="sidebar-header">
          <h2 style={{ margin: 0, display: 'flex', alignItems: 'center', gap: '10px', background: 'linear-gradient(to right, var(--primary), #8b5cf6)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
            <Shield color="var(--primary)" /> CryptoKMS
          </h2>
        </div>
        
        <nav className="sidebar-nav">
          <Link to="/dashboard" style={{ textDecoration: 'none' }}>
            <div className={`nav-item ${location.pathname === '/dashboard' ? 'active' : ''}`}>
              <KeySquare size={20} /> Crypto Engine
            </div>
          </Link>

          <Link to="/vault" style={{ textDecoration: 'none' }}>
            <div className={`nav-item ${location.pathname === '/vault' ? 'active' : ''}`}>
              <Shield size={20} /> Identity Vault
            </div>
          </Link>

          {userData?.role === 'admin' && (
            <Link to="/admin-requests" style={{ textDecoration: 'none' }}>
              <div className={`nav-item ${location.pathname === '/admin-requests' ? 'active' : ''}`}>
                <History size={20} /> Vault Requests
              </div>
            </Link>
          )}

          <Link to="/settings" style={{ textDecoration: 'none', marginTop: 'auto' }}>
            <div className={`nav-item ${location.pathname === '/settings' ? 'active' : ''}`}>
              <Settings size={20} /> Settings
            </div>
          </Link>
        </nav>
      </aside>

      <div className="main-wrapper">
        <header className="top-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
            <button className="menu-toggle" onClick={() => setSidebarOpen(true)}>
              <Menu size={24} />
            </button>
            <span style={{ fontWeight: 'bold', display: sidebarOpen ? 'none' : 'block' }}>
              {location.pathname === '/vault' ? 'Identity Vault' : location.pathname === '/admin-requests' ? 'Command Center' : location.pathname === '/settings' ? 'Settings' : 'Dashboard'}
            </span>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '20px' }}>
            <button onClick={toggleTheme} style={{ background: 'none', border: 'none', color: 'var(--text)', cursor: 'pointer' }}>
              {isDark ? <Sun size={22} /> : <Moon size={22} />}
            </button>
            
            {user && (
              <button onClick={handleLogout} style={{ background: '#ef4444', color: 'white', border: 'none', padding: '8px 12px', borderRadius: '6px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '5px', fontSize: '14px' }}>
                <LogOut size={16} /> Exit
              </button>
            )}
          </div>
        </header>

        <main className="page-content">
          {children}
        </main>

        <footer className="bottom-footer">
          &copy; {new Date().getFullYear()} CryptoKMS SaaS Platform. Enterprise Security.
        </footer>
      </div>
    </div>
  );
}