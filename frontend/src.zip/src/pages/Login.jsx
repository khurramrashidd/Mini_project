import React, { useState } from 'react';
import { auth, googleProvider, db } from '../firebase';
import { signInWithPopup, signInWithEmailAndPassword, createUserWithEmailAndPassword } from 'firebase/auth';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import { Mail, Key, LayoutDashboard, User, Phone, Target } from 'lucide-react';

// DEFINE YOUR ADMIN EMAILS HERE
const ADMIN_EMAILS = ['khurramrashid0786@gmail.com', 'admin@example.com'];

export default function Login() {
  const [isRegistering, setIsRegistering] = useState(false);
  const [formData, setFormData] = useState({ name: '', email: '', password: '', mobile: '', purpose: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  // Helper to save user profile to database
  const saveUserProfile = async (uid, email, name, mobile, purpose) => {
    const role = ADMIN_EMAILS.includes(email) ? 'admin' : 'user';
    await setDoc(doc(db, "users", uid), { name, email, mobile, purpose, role });
  };

  const handleEmailAuth = async (e) => {
    e.preventDefault();
    setLoading(true); setError('');
    try {
      if (isRegistering) {
        const cred = await createUserWithEmailAndPassword(auth, formData.email, formData.password);
        await saveUserProfile(cred.user.uid, formData.email, formData.name, formData.mobile, formData.purpose);
      } else {
        await signInWithEmailAndPassword(auth, formData.email, formData.password);
      }
    } catch (err) {
      setError(err.message.replace('Firebase: ', ''));
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleAuth = async () => {
    try {
      const res = await signInWithPopup(auth, googleProvider);
      // Check if user already exists in DB
      const userDoc = await getDoc(doc(db, 'users', res.user.uid));
      if (!userDoc.exists()) {
        // If new Google user, create a default profile
        await saveUserProfile(res.user.uid, res.user.email, res.user.displayName || 'Google User', 'Not Provided', 'General Access');
      }
    } catch (err) {
      setError('Google Login Failed.');
    }
  };

  return (
    <div style={{ minHeight: '80vh', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '20px' }}>
      <div className="card" style={{ maxWidth: '400px', width: '100%', textAlign: 'center' }}>
        <div style={{ display: 'flex', justifyContent: 'center', marginBottom: '20px' }}>
          <div style={{ background: 'rgba(59, 130, 246, 0.1)', padding: '15px', borderRadius: '50%', color: 'var(--primary)' }}><LayoutDashboard size={40} /></div>
        </div>
        
        <h2 style={{ margin: '0 0 5px 0' }}>SaaS Access Hub</h2>
        <p style={{ color: 'var(--text-muted)', marginBottom: '30px' }}>{isRegistering ? 'Create your Enterprise Account' : 'Authenticate to access the KMS'}</p>

        {error && <div style={{ background: '#fee2e2', color: '#ef4444', padding: '10px', borderRadius: '8px', marginBottom: '20px', fontSize: '14px' }}>{error}</div>}

        <form onSubmit={handleEmailAuth} style={{ display: 'flex', flexDirection: 'column', gap: '15px', marginBottom: '20px' }}>
          
          {isRegistering && (
            <>
              <div style={{ position: 'relative' }}>
                <User size={18} style={{ position: 'absolute', left: '12px', top: '14px', color: 'var(--text-muted)' }} />
                <input type="text" placeholder="Full Name" required value={formData.name} onChange={(e)=>setFormData({...formData, name: e.target.value})} className="input-field" style={{ paddingLeft: '40px' }} />
              </div>
              <div style={{ position: 'relative' }}>
                <Phone size={18} style={{ position: 'absolute', left: '12px', top: '14px', color: 'var(--text-muted)' }} />
                <input type="tel" placeholder="Mobile Number" required value={formData.mobile} onChange={(e)=>setFormData({...formData, mobile: e.target.value})} className="input-field" style={{ paddingLeft: '40px' }} />
              </div>
              <div style={{ position: 'relative' }}>
                <Target size={18} style={{ position: 'absolute', left: '12px', top: '14px', color: 'var(--text-muted)' }} />
                <input type="text" placeholder="Purpose of Use" required value={formData.purpose} onChange={(e)=>setFormData({...formData, purpose: e.target.value})} className="input-field" style={{ paddingLeft: '40px' }} />
              </div>
            </>
          )}

          <div style={{ position: 'relative' }}>
            <Mail size={18} style={{ position: 'absolute', left: '12px', top: '14px', color: 'var(--text-muted)' }} />
            <input type="email" placeholder="Email Address" required value={formData.email} onChange={(e)=>setFormData({...formData, email: e.target.value})} className="input-field" style={{ paddingLeft: '40px' }} />
          </div>
          <div style={{ position: 'relative' }}>
            <Key size={18} style={{ position: 'absolute', left: '12px', top: '14px', color: 'var(--text-muted)' }} />
            <input type="password" placeholder="Password" required value={formData.password} onChange={(e)=>setFormData({...formData, password: e.target.value})} className="input-field" style={{ paddingLeft: '40px' }} />
          </div>
          <button type="submit" className="btn" disabled={loading}>
            {loading ? 'Processing...' : (isRegistering ? 'Create Account' : 'Secure Login')}
          </button>
        </form>

        <div style={{ borderTop: '1px solid var(--border)', paddingTop: '20px', marginBottom: '20px' }}>
          <button onClick={handleGoogleAuth} className="btn" style={{ background: 'var(--bg)', color: 'var(--text)', border: '1px solid var(--border)' }}>
            <img src="https://www.svgrepo.com/show/475656/google-color.svg" alt="Google" style={{ width: '20px' }} /> Continue with Google
          </button>
        </div>

        <button onClick={() => setIsRegistering(!isRegistering)} style={{ background: 'none', border: 'none', color: 'var(--primary)', cursor: 'pointer', fontSize: '14px' }}>
          {isRegistering ? 'Already have an account? Login here.' : 'Need access? Register here.'}
        </button>
      </div>
    </div>
  );
}