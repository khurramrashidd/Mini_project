import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Sun, Moon, LogOut, Menu, Shield, History, Settings, KeySquare, Database } from 'lucide-react';
import { auth } from '../firebase';
import { signOut } from 'firebase/auth';
import '../styles/layout.css';

export default function Layout({ isDark, setIsDark, user, userData, children }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const location = useLocation();

  const toggleTheme = () => {
    setIsDark(!isDark);
    document.documentElement.classList.toggle('dark');
  };

  // Added the new "Manage Credentials" route here
  const navLinks = [
    { path: '/dashboard', icon: KeySquare, label: 'Crypto Engine' },
    { path: '/vault', icon: Shield, label: 'Identity Vault' },
    { path: '/manage-credentials', icon: Database, label: 'Manage Credentials' },
    ...(userData?.role === 'admin' ? [{ path: '/admin-requests', icon: History, label: 'Vault Requests' }] : []),
    { path: '/settings', icon: Settings, label: 'Settings' }
  ];

  return (
    <div className="app-layout">
      {sidebarOpen && (
        <div 
          className="sidebar-overlay" 
          onClick={() => setSidebarOpen(false)}
          aria-label="Close sidebar"
          role="button"
          tabIndex={0}
        />
      )}
      
      <aside className={`sidebar ${sidebarOpen ? 'open' : ''}`} aria-label="Main Navigation">
        <div className="sidebar-header">
          <h2 style={{ margin: 0, display: 'flex', alignItems: 'center', gap: '12px', fontSize: '1.5rem', fontWeight: 800 }}>
            <Shield className="text-primary" size={28} style={{ color: 'var(--primary)' }} /> 
            <span style={{ background: 'linear-gradient(135deg, var(--primary), var(--secondary))', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>CryptoKMS</span>
          </h2>
        </div>
        
        <nav className="sidebar-nav">
          {navLinks.map((link) => (
            <Link key={link.path} to={link.path} style={{ textDecoration: 'none' }} onClick={() => setSidebarOpen(false)}>
              <div className={`nav-item ${location.pathname === link.path ? 'active' : ''}`}>
                <link.icon size={20} />
                <span>{link.label}</span>
              </div>
            </Link>
          ))}
        </nav>
      </aside>

      <div className="main-wrapper">
        <header className="top-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <button 
              className="menu-toggle" 
              onClick={() => setSidebarOpen(true)}
              aria-label="Open Menu"
              style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text)' }}
            >
              <Menu size={28} />
            </button>
            <h2 style={{ margin: 0, fontSize: '1.25rem', fontWeight: 600, display: sidebarOpen ? 'none' : 'block' }}>
              {navLinks.find(l => l.path === location.pathname)?.label || 'Dashboard'}
            </h2>
          </div>
          
          {/* Applied responsive classes here to prevent squishing */}
          <div className="header-actions" style={{ display: 'flex', alignItems: 'center', gap: '24px' }}>
            <button 
              onClick={toggleTheme} 
              aria-label="Toggle Theme"
              style={{ background: 'rgba(128, 128, 128, 0.1)', border: 'none', padding: '10px', borderRadius: '50%', color: 'var(--text)', cursor: 'pointer', transition: 'var(--transition)' }}
            >
              {isDark ? <Sun size={20} /> : <Moon size={20} />}
            </button>
            
            {user && (
              <button 
                onClick={() => signOut(auth)} 
                className="btn exit-btn"
                style={{ background: 'var(--danger)', padding: '10px 20px', borderRadius: '10px', boxShadow: 'none' }}
              >
                <LogOut size={18} /> <span className="exit-text">Exit</span>
              </button>
            )}
          </div>
        </header>

        <main className="page-content" id="main-content">
          {children}
        </main>
      </div>
    </div>
  );
}