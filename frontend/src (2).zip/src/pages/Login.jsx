import React, { useState } from 'react';
import { auth, googleProvider, db } from '../firebase';
import { signInWithPopup, signInWithEmailAndPassword, createUserWithEmailAndPassword } from 'firebase/auth';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import { Mail, Key, ShieldCheck, User, Phone, Target } from 'lucide-react';

const ADMIN_EMAILS = ['khurramrashid0786@gmail.com', 'admin@example.com'];

export default function Login() {
  const [isRegistering, setIsRegistering] = useState(false);
  const [formData, setFormData] = useState({ name: '', email: '', password: '', mobile: '', purpose: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const saveUserProfile = async (uid, email, name, mobile, purpose) => {
    const role = ADMIN_EMAILS.includes(email) ? 'admin' : 'user';
    await setDoc(doc(db, "users", uid), { name, email, mobile, purpose, role });
  };

  const handleEmailAuth = async (e) => {
    e.preventDefault();
    setLoading(true); setError('');
    try {
      if (isRegistering) {
        const cred = await createUserWithEmailAndPassword(auth, formData.email, formData.password);
        await saveUserProfile(cred.user.uid, formData.email, formData.name, formData.mobile, formData.purpose);
      } else {
        await signInWithEmailAndPassword(auth, formData.email, formData.password);
      }
    } catch (err) {
      setError(err.message.replace('Firebase: ', ''));
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleAuth = async () => {
    try {
      const res = await signInWithPopup(auth, googleProvider);
      const userDoc = await getDoc(doc(db, 'users', res.user.uid));
      if (!userDoc.exists()) {
        await saveUserProfile(res.user.uid, res.user.email, res.user.displayName || 'Google User', 'Not Provided', 'General Access');
      }
    } catch (err) {
      setError('Google Login Failed.');
    }
  };

  return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '20px' }}>
      <div className="card" style={{ maxWidth: '450px', width: '100%', textAlign: 'center', animation: 'fadeIn 0.6s ease-out' }}>
        <div style={{ display: 'flex', justifyContent: 'center', marginBottom: '24px' }}>
          <div style={{ background: 'linear-gradient(135deg, var(--primary), var(--secondary))', padding: '16px', borderRadius: '50%', color: 'white', boxShadow: '0 8px 20px rgba(79, 70, 229, 0.4)' }}>
            <ShieldCheck size={48} />
          </div>
        </div>
        
        <h2 style={{ margin: '0 0 8px 0', fontSize: '1.8rem', fontWeight: 800 }}>SaaS Access Hub</h2>
        <p style={{ color: 'var(--text-muted)', marginBottom: '32px', fontSize: '1rem' }}>
          {isRegistering ? 'Provision your Enterprise Clearance' : 'Authenticate to access the CryptoKMS'}
        </p>

        {error && (
          <div style={{ background: 'rgba(239, 68, 68, 0.1)', color: 'var(--danger)', padding: '12px', borderRadius: '10px', border: '1px solid var(--danger)', marginBottom: '24px', fontSize: '14px', fontWeight: 500 }}>
            {error}
          </div>
        )}

        <form onSubmit={handleEmailAuth} style={{ display: 'flex', flexDirection: 'column', gap: '16px', marginBottom: '24px' }}>
          {isRegistering && (
            <>
              <div style={{ position: 'relative' }}>
                <User size={20} style={{ position: 'absolute', left: '16px', top: '16px', color: 'var(--text-muted)' }} />
                <input type="text" placeholder="Full Name" required value={formData.name} onChange={(e)=>setFormData({...formData, name: e.target.value})} className="input-field" style={{ paddingLeft: '48px' }} />
              </div>
              <div style={{ position: 'relative' }}>
                <Phone size={20} style={{ position: 'absolute', left: '16px', top: '16px', color: 'var(--text-muted)' }} />
                <input type="tel" placeholder="Mobile Number" required value={formData.mobile} onChange={(e)=>setFormData({...formData, mobile: e.target.value})} className="input-field" style={{ paddingLeft: '48px' }} />
              </div>
              <div style={{ position: 'relative' }}>
                <Target size={20} style={{ position: 'absolute', left: '16px', top: '16px', color: 'var(--text-muted)' }} />
                <input type="text" placeholder="Purpose of Use" required value={formData.purpose} onChange={(e)=>setFormData({...formData, purpose: e.target.value})} className="input-field" style={{ paddingLeft: '48px' }} />
              </div>
            </>
          )}
          <div style={{ position: 'relative' }}>
            <Mail size={20} style={{ position: 'absolute', left: '16px', top: '16px', color: 'var(--text-muted)' }} />
            <input type="email" placeholder="Email Address" required value={formData.email} onChange={(e)=>setFormData({...formData, email: e.target.value})} className="input-field" style={{ paddingLeft: '48px' }} />
          </div>
          <div style={{ position: 'relative' }}>
            <Key size={20} style={{ position: 'absolute', left: '16px', top: '16px', color: 'var(--text-muted)' }} />
            <input type="password" placeholder="Password" required value={formData.password} onChange={(e)=>setFormData({...formData, password: e.target.value})} className="input-field" style={{ paddingLeft: '48px' }} />
          </div>
          <button type="submit" className="btn" disabled={loading} style={{ marginTop: '8px', padding: '16px' }}>
            {loading ? <span className="spinner">Processing...</span> : (isRegistering ? 'Establish Clearance' : 'Secure Authorization')}
          </button>
        </form>

        <div style={{ borderTop: '1px solid var(--border)', paddingTop: '24px', marginBottom: '24px', position: 'relative' }}>
          <span style={{ position: 'absolute', top: '-12px', left: '50%', transform: 'translateX(-50%)', background: 'var(--bg-surface)', padding: '0 10px', fontSize: '12px', color: 'var(--text-muted)', fontWeight: 600 }}>OR</span>
          <button onClick={handleGoogleAuth} className="btn" style={{ background: 'transparent', color: 'var(--text)', border: '2px solid var(--border)', boxShadow: 'none', width: '100%' }}>
            <img src="https://www.svgrepo.com/show/475656/google-color.svg" alt="Google" style={{ width: '24px' }} /> 
            Continue with Google
          </button>
        </div>

        <button onClick={() => setIsRegistering(!isRegistering)} style={{ background: 'none', border: 'none', color: 'var(--primary)', cursor: 'pointer', fontSize: '15px', fontWeight: 600 }}>
          {isRegistering ? 'Already provisioned? Authorize here.' : 'Require access? Request clearance.'}
        </button>
      </div>
    </div>
  );
}