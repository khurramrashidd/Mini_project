import React, { useState, useEffect } from 'react';
import { collection, query, onSnapshot, doc, updateDoc, addDoc } from 'firebase/firestore';
import { db } from '../firebase';
import axios from 'axios';
import { CheckCircle2, Clock, Shield, Send, Activity, Eye, EyeOff, Copy, AlertTriangle, XCircle } from 'lucide-react';

export default function AdminRequests() {
  const [requests, setRequests] = useState([]);
  const [visibleKeys, setVisibleKeys] = useState({});
  
  const [activeRequest, setActiveRequest] = useState(null);
  const [pipelineState, setPipelineState] = useState('idle'); 
  const [pipelineResults, setPipelineResults] = useState([]);

  useEffect(() => {
    const q = query(collection(db, 'passwordRequests'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      // Sort by newest first
      const fetchedRequests = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      fetchedRequests.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
      setRequests(fetchedRequests);
    });
    return unsubscribe;
  }, []);

  const handleAcceptRequest = (req) => {
    setActiveRequest(req);
    setPipelineState('idle');
    setPipelineResults([]);
  };

  const declineRequest = async (requestId) => {
    if (window.confirm("Are you sure you want to decline this request?")) {
      try {
        await updateDoc(doc(db, 'passwordRequests', requestId), {
          status: 'Declined',
          processedAt: new Date().toISOString()
        });
      } catch (err) {
        console.error("Failed to decline request:", err);
      }
    }
  };

  // The Cryptographic Compliance Checker
  const checkCompliance = (key, reqLength, reqChars) => {
    const isLongEnough = key.length >= parseInt(reqLength || 0);
    const hasUpper = reqChars?.upper ? /[A-Z]/.test(key) : true;
    const hasLower = reqChars?.lower ? /[a-z]/.test(key) : true;
    const hasNumbers = reqChars?.numbers ? /[0-9]/.test(key) : true;
    const hasSymbols = reqChars?.symbols ? /[^A-Za-z0-9]/.test(key) : true;

    const passes = isLongEnough && hasUpper && hasLower && hasNumbers && hasSymbols;
    
    return {
      passes,
      details: { length: isLongEnough, upper: hasUpper, lower: hasLower, numbers: hasNumbers, symbols: hasSymbols }
    };
  };

  const runCompleteSynthesisPipeline = async () => {
    setPipelineState('running');
    try {
      const API_URL = 'https://minicrypto.onrender.com/api/generate-key';
      
      const [aesRes, rsaRes, eccRes] = await Promise.all([
        axios.post(API_URL, { purpose: activeRequest.purpose, algorithm: 'AES', length: 256 }),
        axios.post(API_URL, { purpose: activeRequest.purpose, algorithm: 'RSA', length: 2048 }),
        axios.post(API_URL, { purpose: activeRequest.purpose, algorithm: 'ECC', length: 256 })
      ]);

      setPipelineResults([aesRes.data, rsaRes.data, eccRes.data]);
      setPipelineState('generated');
    } catch (err) {
      console.error(err);
      alert('Pipeline execution failed. Ensure backend is running.');
      setPipelineState('idle');
    }
  };

  const dispatchSelectedKey = async (selectedResult) => {
    try {
      const generatedCredential = selectedResult.key_data.key_hex || selectedResult.key_data.private_key;

      await addDoc(collection(db, `users/${activeRequest.userId}/vault`), {
        label: activeRequest.label,
        purpose: activeRequest.purpose,
        password: generatedCredential,
        algorithm: selectedResult.metadata.algorithm,
        heuristicScore: 'Verified by Command Center',
        source: 'Admin-Issued (Command Center)',
        createdAt: new Date().toISOString(),
        expiresAt: activeRequest.expiresAt || new Date().toISOString(),
        status: 'Active'
      });

      await updateDoc(doc(db, 'passwordRequests', activeRequest.id), {
        status: 'Completed',
        processedAt: new Date().toISOString(),
        dispatchedPassword: generatedCredential,
        dispatchedAlgorithm: selectedResult.metadata.algorithm
      });

      setActiveRequest(null);
      setPipelineResults([]);
      setPipelineState('idle');

    } catch (err) {
      console.error(err);
      alert('Failed to dispatch credential to user.');
    }
  };

  const pendingRequests = requests.filter(r => r.status === 'Pending');
  const processedRequests = requests.filter(r => r.status === 'Completed' || r.status === 'Declined');

  return (
    <div className="dashboard-container">
      <h1>Admin Command Center</h1>
      <p style={{ color: 'var(--text-muted)' }}>Review user requests, run the 3-Way Crypto Pipeline, and oversee dispatched organizational credentials.</p>

      {/* SECTION 1: PENDING REQUESTS */}
      <h3 style={{ marginTop: '30px', borderBottom: '1px solid var(--border)', paddingBottom: '10px' }}>Pending Action Queue</h3>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '20px', marginTop: '20px' }}>
        {pendingRequests.length === 0 && <p style={{ color: 'var(--text-muted)' }}>No pending requests at this time.</p>}
        {pendingRequests.map(req => (
          <div key={req.id} className="card" style={{ borderLeft: '4px solid #f59e0b' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <h2 style={{ fontSize: '1.2rem', margin: '0 0 10px 0' }}>{req.label}</h2>
                <div style={{ fontSize: '14px', color: 'var(--text-muted)', display: 'flex', gap: '20px', flexWrap: 'wrap' }}>
                  <span><strong>User:</strong> {req.userName}</span>
                  <span><strong>Purpose:</strong> {req.purpose}</span>
                  <span style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
                    <Clock size={14}/> Expiry: {new Date(req.expiresAt).toLocaleDateString()}
                  </span>
                </div>
                <div style={{ fontSize: '13px', marginTop: '8px', color: '#8b5cf6' }}>
                  <strong>User Requested Params:</strong> Length: {req.reqLength || 'N/A'} | Chars: {req.reqChars?.upper ? 'A-Z ' : ''}{req.reqChars?.lower ? 'a-z ' : ''}{req.reqChars?.numbers ? '0-9 ' : ''}{req.reqChars?.symbols ? '!@#' : ''}
                </div>
              </div>

              <div>
                {activeRequest?.id !== req.id && (
                  <div style={{ display: 'flex', gap: '10px' }}>
                    <button className="btn" onClick={() => declineRequest(req.id)} style={{ background: 'transparent', border: '1px solid #ef4444', color: '#ef4444' }}>
                      Decline
                    </button>
                    <button className="btn" onClick={() => handleAcceptRequest(req)} style={{ background: '#f59e0b' }}>
                      Review Request
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* THE EXPANDED ADMIN WORKSPACE */}
            {activeRequest?.id === req.id && (
              <div style={{ marginTop: '20px', padding: '20px', background: 'var(--bg)', borderRadius: '8px', border: '1px solid var(--primary)' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
                  <h4 style={{ margin: 0, display: 'flex', alignItems: 'center', gap: '5px', color: 'var(--primary)', fontSize: '1.1rem' }}>
                    <Shield size={20} /> 3-Way Synthesis Pipeline Workspace
                  </h4>
                  <button onClick={() => setActiveRequest(null)} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}>Close Workspace</button>
                </div>
                
                {pipelineState === 'idle' && (
                  <button className="btn" onClick={runCompleteSynthesisPipeline} style={{ background: '#8b5cf6', width: '100%', padding: '15px' }}>
                    <Activity size={20} /> Initialize Complete Pipeline (AES, RSA, ECC)
                  </button>
                )}

                {pipelineState === 'running' && (
                  <div style={{ textAlign: 'center', color: '#8b5cf6', padding: '20px', fontWeight: 'bold' }}>
                    Engaging Math & AI Agents across 3 Algorithms...
                  </div>
                )}

                {pipelineState === 'generated' && (
                  <div className="results-grid" style={{ animation: 'slideDown 0.4s ease-out' }}>
                    {pipelineResults.map((res, index) => {
                       const aiScore = res.pipeline_agents.Agent_2_AI.ai_confidence_score;
                       const mathScore = (res.pipeline_agents.Agent_3_Math.shannon_entropy / res.pipeline_agents.Agent_3_Math.max_theoretical_entropy) * 100;
                       
                       const keyString = res.key_data.key_hex || res.key_data.private_key;
                       const compliance = checkCompliance(keyString, req.reqLength, req.reqChars);

                       return (
                        <div key={index} className="algo-card" style={{ background: 'var(--card)', border: compliance.passes ? '2px solid var(--success)' : '1px solid var(--border)' }}>
                          <div className="card-header">
                            <h2>{res.metadata.algorithm}</h2>
                            <span className="security-badge">{res.metadata.bits}-bit</span>
                          </div>
                          
                          <div style={{ fontSize: '13px', margin: '10px 0' }}>
                            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '5px' }}><span>Resistance:</span> <strong>{res.pipeline_agents.Agent_4_Strength.brute_force_resistance}</strong></div>
                            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '5px' }}><span>Entropy Health:</span> <strong>{mathScore.toFixed(1)}%</strong></div>
                            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '5px' }}><span>AI Confidence:</span> <strong>{aiScore.toFixed(1)}%</strong></div>
                          </div>

                          {/* COMPLIANCE CHECKER UI */}
                          <div style={{ padding: '10px', background: compliance.passes ? 'rgba(16, 185, 129, 0.1)' : 'rgba(239, 68, 68, 0.1)', borderRadius: '6px', fontSize: '12px', marginBottom: '10px' }}>
                            <strong style={{ color: compliance.passes ? 'var(--success)' : '#ef4444', display: 'flex', alignItems: 'center', gap: '4px' }}>
                              {compliance.passes ? <CheckCircle2 size={14}/> : <AlertTriangle size={14}/>} 
                              {compliance.passes ? ' Meets User Criteria' : ' Fails User Criteria'}
                            </strong>
                          </div>

                          <code style={{ background: 'var(--bg)', padding: '10px', borderRadius: '4px', display: 'block', wordBreak: 'break-all', fontSize: '11px', color: 'var(--text)', border: '1px solid var(--border)', maxHeight: '60px', overflowY: 'auto' }}>
                            {keyString}
                          </code>

                          <button className="btn" onClick={() => dispatchSelectedKey(res)} style={{ background: 'var(--success)', marginTop: '15px', width: '100%' }}>
                            <Send size={16} /> Dispatch this Key
                          </button>
                        </div>
                      )
                    })}
                  </div>
                )}
              </div>
            )}
          </div>
        ))}
      </div>

      {/* SECTION 2: PROCESSED CREDENTIALS */}
      <h3 style={{ marginTop: '50px', borderBottom: '1px solid var(--border)', paddingBottom: '10px' }}>Processed Dispatches & Declines</h3>
      <div className="card" style={{ marginTop: '20px' }}>
        <table style={{ width: '100%', textAlign: 'left', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ borderBottom: '1px solid var(--border)', color: 'var(--text-muted)' }}>
              <th style={{ padding: '10px' }}>Target User</th>
              <th>Vault Label / Purpose</th>
              <th>Status</th>
              <th>Dispatched Credential</th>
              <th style={{ textAlign: 'center' }}>Action</th>
            </tr>
          </thead>
          <tbody>
            {processedRequests.length === 0 && (
              <tr><td colSpan="5" style={{ padding: '20px', textAlign: 'center', color: 'var(--text-muted)' }}>No requests processed yet.</td></tr>
            )}
            {processedRequests.map(entry => (
              <tr key={entry.id} style={{ borderBottom: '1px solid var(--border)', opacity: entry.status === 'Declined' ? 0.6 : 1 }}>
                <td style={{ padding: '15px 10px' }}>
                  <strong>{entry.userName}</strong>
                </td>
                <td>
                  <strong>{entry.label}</strong><br/>
                  <span style={{ fontSize: '12px', color: 'var(--text-muted)' }}>{entry.purpose}</span>
                </td>
                <td>
                   {entry.status === 'Completed' ? (
                     <span style={{ background: 'rgba(16, 185, 129, 0.1)', color: 'var(--success)', padding: '4px 8px', borderRadius: '4px', fontSize: '12px', display: 'inline-flex', alignItems: 'center', gap: '4px' }}><CheckCircle2 size={12}/> Dispatched</span>
                   ) : (
                     <span style={{ background: 'rgba(239, 68, 68, 0.1)', color: '#ef4444', padding: '4px 8px', borderRadius: '4px', fontSize: '12px', display: 'inline-flex', alignItems: 'center', gap: '4px' }}><XCircle size={12}/> Declined</span>
                   )}
                </td>
                <td style={{ maxWidth: '300px', paddingRight: '15px' }}>
                  {entry.status === 'Completed' ? (
                    <div style={{ display: 'flex', gap: '10px', alignItems: 'flex-start' }}>
                      <code style={{ background: 'var(--bg)', padding: '10px', borderRadius: '6px', display: 'block', wordBreak: 'break-all', whiteSpace: 'pre-wrap', fontSize: '12px', color: 'var(--primary)', flex: 1, border: '1px solid var(--border)' }}>
                        {visibleKeys[entry.id] ? (entry.dispatchedPassword || 'Masked/Legacy Data') : '••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••'}
                      </code>
                      <button onClick={() => { navigator.clipboard.writeText(entry.dispatchedPassword); alert('Credential Copied to Clipboard!'); }} style={{ background: 'var(--card)', border: '1px solid var(--border)', padding: '8px', borderRadius: '6px', cursor: 'pointer', color: 'var(--text)', flexShrink: 0 }} title="Copy full key">
                        <Copy size={16} />
                      </button>
                    </div>
                  ) : (
                    <span style={{ color: 'var(--text-muted)', fontSize: '12px' }}>Request Denied</span>
                  )}
                </td>
                <td style={{ display: 'flex', gap: '10px', justifyContent: 'center', marginTop: '15px' }}>
                  {entry.status === 'Completed' && (
                    <button onClick={() => setVisibleKeys({...visibleKeys, [entry.id]: !visibleKeys[entry.id]})} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text)' }}>
                      {visibleKeys[entry.id] ? <EyeOff size={18} /> : <Eye size={18} />}
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}