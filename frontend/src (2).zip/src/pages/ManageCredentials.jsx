import React, { useState, useEffect } from 'react';
import { collection, query, onSnapshot, doc, updateDoc, deleteDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { Trash2, ShieldAlert, ShieldCheck, Database, Calendar, Clock } from 'lucide-react';

export default function ManageCredentials({ user }) {
  const [credentials, setCredentials] = useState([]);

  useEffect(() => {
    const q = query(collection(db, `users/${user.uid}/vault`));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const entries = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      entries.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
      setCredentials(entries);
    });
    return unsubscribe;
  }, [user.uid]);

  const toggleStatus = async (id, currentStatus) => {
    const newStatus = currentStatus === 'Active' ? 'Inactive' : 'Active';
    const updatePayload = { status: newStatus };

    // FEATURE REQUIREMENT: If manually marked inactive, set expiry to EXACT CURRENT Date & Time.
    if (newStatus === 'Inactive') {
      updatePayload.expiresAt = new Date().toISOString();
    }

    try {
      await updateDoc(doc(db, `users/${user.uid}/vault`, id), updatePayload);
    } catch (err) {
      alert("Failed to update status.");
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm("Are you sure you want to permanently delete this credential?")) {
      try {
        await deleteDoc(doc(db, `users/${user.uid}/vault`, id));
      } catch (err) {
        alert("Failed to delete credential.");
      }
    }
  };

  // Updated to include precise time
  const formatDateTime = (dateString) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleString(undefined, {
      year: 'numeric', month: 'short', day: 'numeric',
      hour: '2-digit', minute: '2-digit'
    });
  };

  return (
    <div className="dashboard-container">
      <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '20px' }}>
        <Database size={32} color="var(--primary)" />
        <h1 style={{ margin: 0 }}>Credential Management</h1>
      </div>
      <p style={{ color: 'var(--text-muted)', marginBottom: '30px' }}>
        Review your complete history of generated keys. Mark credentials as inactive to instantly revoke their operational status and record the exact time of revocation.
      </p>

      <div className="card" style={{ padding: '20px' }}>
        <table className="mc-table">
          <thead>
            <tr style={{ borderBottom: '2px solid var(--border)', color: 'var(--text-muted)' }}>
              <th style={{ padding: '12px', textAlign: 'left' }}>Vault Label</th>
              <th style={{ padding: '12px', textAlign: 'left' }}>Purpose</th>
              <th style={{ padding: '12px', textAlign: 'left' }}>Lifecycle</th>
              <th style={{ padding: '12px', textAlign: 'left' }}>Status</th>
              <th style={{ padding: '12px', textAlign: 'center' }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {credentials.length === 0 && (
              <tr>
                <td colSpan="5" style={{ textAlign: 'center', padding: '30px', color: 'var(--text-muted)' }}>
                  No credentials found in your vault.
                </td>
              </tr>
            )}
            {credentials.map(entry => {
              const isAutoExpired = new Date() > new Date(entry.expiresAt);
              const isManuallyInactive = entry.status === 'Inactive';
              const isActive = !isManuallyInactive && !isAutoExpired;
              
              // Determine display status label
              let displayStatus = 'Active';
              if (isManuallyInactive) displayStatus = 'Inactive';
              else if (isAutoExpired) displayStatus = 'Expired';

              return (
                <tr key={entry.id} className={`mc-row ${!isActive ? 'mc-inactive-row' : ''}`}>
                  <td data-label="Vault Label" className="mc-cell">
                    <span className="mc-cell-content" style={{ fontWeight: 'bold', color: 'var(--text)' }}>
                      {entry.label}
                    </span>
                  </td>
                  <td data-label="Purpose" className="mc-cell">
                    <span className="mc-cell-content" style={{ color: 'var(--text-muted)', fontSize: '14px' }}>
                      {entry.purpose}
                    </span>
                  </td>
                  <td data-label="Lifecycle" className="mc-cell">
                    <div className="mc-cell-content" style={{ display: 'flex', flexDirection: 'column', gap: '6px', fontSize: '13px' }}>
                      <span style={{ color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '6px' }}>
                        <Calendar size={14} /> Created: {formatDateTime(entry.createdAt)}
                      </span>
                      {(!isActive && entry.expiresAt) && (
                        <span style={{ color: 'var(--danger)', fontWeight: '600', display: 'flex', alignItems: 'center', gap: '6px' }}>
                          <Clock size={14} /> {isManuallyInactive ? 'Revoked' : 'Expired'}: {formatDateTime(entry.expiresAt)}
                        </span>
                      )}
                    </div>
                  </td>
                  <td data-label="Status" className="mc-cell">
                    <span className="mc-cell-content">
                      <span style={{ 
                        background: isActive ? 'rgba(16, 185, 129, 0.1)' : 'rgba(239, 68, 68, 0.1)', 
                        color: isActive ? 'var(--success)' : 'var(--danger)', 
                        padding: '6px 12px', 
                        borderRadius: '20px', 
                        fontSize: '12px', 
                        fontWeight: 'bold',
                        display: 'inline-block'
                      }}>
                        {displayStatus}
                      </span>
                    </span>
                  </td>
                  <td data-label="Actions" className="mc-cell mc-actions-cell">
                    <div className="mc-actions-wrapper">
                      <button 
                        onClick={() => toggleStatus(entry.id, entry.status || 'Active')} 
                        className="btn"
                        style={{ 
                          background: 'transparent', 
                          border: `1px solid ${isActive ? 'var(--warning)' : 'var(--success)'}`, 
                          color: isActive ? 'var(--warning)' : 'var(--success)', 
                          padding: '8px 14px',
                          fontSize: '13px',
                          boxShadow: 'none',
                          flex: 1
                        }}
                      >
                        {isActive ? <><ShieldAlert size={14}/> Mark Inactive</> : <><ShieldCheck size={14}/> Set Active</>}
                      </button>
                      <button 
                        onClick={() => handleDelete(entry.id)} 
                        style={{ background: 'rgba(239, 68, 68, 0.1)', padding: '8px 12px', borderRadius: '8px', border: '1px solid rgba(239, 68, 68, 0.2)', cursor: 'pointer', color: 'var(--danger)' }} 
                        title="Delete Permanently"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}